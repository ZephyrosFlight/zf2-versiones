#!/bin/bash
# ZephyrosFlight 2 — arranque limpio: logo y barra de progreso en vez de los mensajes del sistema.
#   ./instalar_arranque.sh si   instala la pantalla de arranque
#   ./instalar_arranque.sh no   vuelve a los mensajes de siempre
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
CMD=/boot/firmware/cmdline.txt
CFG=/boot/firmware/config.txt
[ -f "$CMD" ] || CMD=/boot/cmdline.txt
[ -f "$CFG" ] || CFG=/boot/config.txt
OPC="quiet splash loglevel=3 logo.nologo vt.global_cursor_default=0 plymouth.ignore-serial-consoles consoleblank=0"

case "$1" in
  si)
    sudo apt-get install -y plymouth plymouth-themes > /dev/null
    sudo mkdir -p /usr/share/plymouth/themes/zf2
    sudo cp "$DIR"/zf2.plymouth "$DIR"/zf2.script "$DIR"/*.png /usr/share/plymouth/themes/zf2/
    sudo plymouth-set-default-theme zf2
    # opciones del núcleo (todo en una línea; se quitan antes para no repetirlas)
    LINEA="$(head -n1 "$CMD")"
    for o in $OPC console=tty1 console=tty3; do LINEA="$(echo " $LINEA " | sed "s# $o # #g")"; done
    LINEA="$(echo $LINEA) console=tty3 $OPC"
    sudo cp "$CMD" "$CMD.zf2bak"
    echo "$LINEA" | sudo tee "$CMD" > /dev/null
    # sin el cuadro de colores del arranque
    grep -q '^disable_splash=1' "$CFG" || echo 'disable_splash=1' | sudo tee -a "$CFG" > /dev/null
    sudo update-initramfs -u > /dev/null 2>&1 || true
    # la pantalla de arranque se queda hasta que abre el programa (él la quita al empezar)
    sudo systemctl mask plymouth-quit.service plymouth-quit-wait.service > /dev/null 2>&1 || true
    echo "Listo. Reinicia para verlo: sudo reboot"
    ;;
  no)
    [ -f "$CMD.zf2bak" ] && sudo cp "$CMD.zf2bak" "$CMD"
    sudo sed -i '/^disable_splash=1/d' "$CFG"
    sudo systemctl unmask plymouth-quit.service plymouth-quit-wait.service > /dev/null 2>&1 || true
    echo "Quitado. Al reiniciar vuelven los mensajes del sistema."
    ;;
  *)
    echo "Uso: $0 si | no"
    exit 1
    ;;
esac
