#!/bin/bash
# ZephyrosFlight 2 — actualización desde las versiones publicadas (programa ya compilado).
# La lanza el servicio zf2-actualizar al encender, cuando hay red (ver autoarranque.sh), y el
# botón AJUSTES > SISTEMA > BUSCAR ACTUALIZACIÓN (con --manual).
# Descarga el paquete de la última versión, comprueba que está entero y que arranca en esta Pi,
# y lo copia sobre la instalación. El programa en marcha NO se reinicia: la versión nueva se usa
# en el siguiente encendido o con REINICIAR Y APLICAR (solo en tierra).
# Los mapas (~/zf2-mapas) y tus ajustes, aviones y vuelos (~/.config/zf2) no se tocan.
# Deja el resultado en ~/.config/zf2/actualizacion.txt, que se ve en AJUSTES.
URL_BASE="${ZF2_URL:-https://raw.githubusercontent.com/ZephyrosFlight/zf2-versiones/main}"   # ZF2_URL: solo para pruebas
DIR="$(cd "$(dirname "$0")/.." && pwd)"
EST="$HOME/.config/zf2/actualizacion.txt"
LOG=/tmp/zf2-actualizar.log
mkdir -p "$(dirname "$EST")"
fecha() { date '+%d/%m %H:%M'; }
local_ver() { sed -n "s/^$1=//p" "$DIR/VERSION" 2>/dev/null | head -1; }
en_uso() { local v; v=$(local_ver version); [ -n "$v" ] && echo "$v ($(local_ver commit))" || echo "sin version"; }

# AJUSTES > SISTEMA > Automáticas: NO deja actualizar_auto=0 en mapa.cfg: solo a mano
if [ "$1" != "--manual" ] && grep -q '^actualizar_auto=0' "$HOME/.config/zf2/mapa.cfg" 2>/dev/null; then
  echo "Automaticas desactivadas: en uso $(en_uso) ($(fecha))" > "$EST"
  exit 0
fi

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
fallo() { echo "Error al actualizar: $1 ($(fecha))" > "$EST"; echo "$(date) $1" >> "$LOG"; exit 0; }

# ultima.txt por la API de GitHub (caché de 1 min); si falla, por raw (caché de hasta 5 min)
API="https://api.github.com/repos/ZephyrosFlight/zf2-versiones/contents/ultima.txt"
r=1
[ -z "$ZF2_URL" ] && curl -fsSL --max-time 30 -H "Accept: application/vnd.github.raw" "$API" -o "$TMP/ultima.txt" 2>>"$LOG" && r=0
if [ $r -ne 0 ]; then
  curl -fsSL --max-time 30 "$URL_BASE/ultima.txt?t=$(date +%s)" -o "$TMP/ultima.txt" 2>>"$LOG"
  r=$?
fi
if [ $r -eq 22 ]; then fallo "no hay ninguna version publicada"; fi
if [ $r -ne 0 ]; then
  echo "Sin conexion ($(fecha))" > "$EST"
  exit 0
fi
# ajustes del sistema pendientes (sonido Bluetooth…): solo hace algo si falta alguno
[ -x "$DIR/mapa_prueba/sistema.sh" ] && "$DIR/mapa_prueba/sistema.sh" >/dev/null 2>&1
# licencia de esta placa (por su número de serie), si se ha emitido: zf2-versiones/licencias/<serie>.lic
SERIE=$(tr -d '\0' < /proc/device-tree/serial-number 2>/dev/null | tr 'A-F' 'a-f' | tr -d ' \n')
if [ -n "$SERIE" ] && curl -fsSL --max-time 30 "$URL_BASE/licencias/$SERIE.lic?t=$(date +%s)" -o "$TMP/lic" 2>/dev/null \
   && grep -q "^serie=$SERIE" "$TMP/lic" && grep -q '^firma=' "$TMP/lic"; then
  cmp -s "$TMP/lic" "$HOME/.config/zf2/licencia.txt" || cp "$TMP/lic" "$HOME/.config/zf2/licencia.txt"
fi
val() { sed -n "s/^$1=//p" "$TMP/ultima.txt" | head -1; }
VER=$(val version); COM=$(val commit); PQ=$(val paquete); SHA=$(val sha256)
[ -n "$COM" ] && [ -n "$PQ" ] && [ -n "$SHA" ] || fallo "datos de la version incompletos"
if [ "$COM" = "$(local_ver commit)" ]; then
  echo "Al dia: $VER ($COM) ($(fecha))" > "$EST"
  exit 0
fi
curl -fsSL --retry 3 --max-time 600 "$URL_BASE/$PQ" -o "$TMP/p.tgz" 2>>"$LOG" || fallo "no se pudo descargar"
echo "$SHA  $TMP/p.tgz" | sha256sum -c --status || fallo "descarga incompleta o danada"
mkdir "$TMP/x"
tar -xzf "$TMP/p.tgz" -C "$TMP/x" 2>>"$LOG" || fallo "paquete danado"
NEW="$TMP/x/zf2"
"$NEW/mapa_prueba/mapa_prueba" --version >>"$LOG" 2>&1 || fallo "la version nueva no arranca en esta Pi"
# copia sobre la instalación: cada fichero se sustituye entero (el programa en marcha sigue con el suyo)
cp -r --remove-destination "$NEW/." "$DIR/" 2>>"$LOG" || fallo "no se pudo copiar"
touch "$DIR/mapa_prueba/mapa_prueba"     # la app ve que hay una versión nueva pendiente
[ -x "$DIR/mapa_prueba/sistema.sh" ] && "$DIR/mapa_prueba/sistema.sh" >/dev/null 2>&1   # lo que traiga de sistema
echo "Nueva version $VER ($COM): se usara al reiniciar ($(fecha))" > "$EST"
exit 0
