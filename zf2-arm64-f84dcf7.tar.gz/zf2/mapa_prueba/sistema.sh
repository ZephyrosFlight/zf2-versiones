#!/bin/bash
# ZephyrosFlight 2 — ajustes del sistema que necesita el programa y que no van en el paquete:
# sonido (PipeWire) con cascos Bluetooth para los avisos de voz, y girar el arranque en las
# pantallas verticales de fábrica (AJUSTES › GENERAL › Orientación).
#
# Lo ejecutan autoarranque.sh (instalación) y actualizar.sh (después de cada actualización).
# Es idempotente y lleva versión: solo hace algo si la de este fichero es más nueva que la última
# aplicada (~/.config/zf2/sistema.txt). Necesita sudo sin contraseña (el usuario de Raspberry Pi OS
# lo tiene normalmente; si no, ejecutarlo una vez a mano en una terminal, que pide la contraseña)
# e internet para instalar paquetes; si algo falla, lo vuelve a intentar la próxima vez.
VERSION_SISTEMA=4
CFG="$HOME/.config/zf2"
LOG="$CFG/sistema.log"
mkdir -p "$CFG"
HECHA=$(cat "$CFG/sistema.txt" 2>/dev/null || echo 0)
[ "$1" != "--forzar" ] && [ "$HECHA" -ge "$VERSION_SISTEMA" ] 2>/dev/null && exit 0
if [ -t 1 ]; then
  # a mano en una terminal: pide la contraseña una vez y enseña lo que hace (y lo guarda)
  echo "ZephyrosFlight 2: preparando el sistema (sonido Bluetooth y giro del arranque). Puede pedir la contraseña de la Pi."
  sudo -v || { echo "Sin permiso de administrador: no se aplica"; exit 1; }
  exec > >(tee -a "$LOG") 2>&1
else
  exec >>"$LOG" 2>&1
fi
echo "=== $(date) sistema $HECHA -> $VERSION_SISTEMA"
sudo -n true 2>/dev/null || { echo "sin sudo sin contrasena: no se aplica (ejecutar a mano: ~/zf2/mapa_prueba/sistema.sh)"; exit 0; }
USUARIO="$(id -un)"; UID_U="$(id -u)"
ok=1

# 1) paquetes: PipeWire (sonido), su parte de Bluetooth, BlueZ y pdftoppm (cartas VAC en PDF)
PAQ="pipewire pipewire-pulse wireplumber libspa-0.2-bluetooth bluez poppler-utils"   # poppler-utils: PDF de las cartas VAC (portal)
if ! dpkg -s $PAQ >/dev/null 2>&1; then
  sudo -n apt-get update -q && sudo -n DEBIAN_FRONTEND=noninteractive apt-get install -y -q $PAQ || ok=0
fi
sudo -n usermod -aG bluetooth,audio "$USUARIO" || true
sudo -n systemctl enable --now bluetooth.service || true
sudo -n rfkill unblock bluetooth 2>/dev/null || true

# 2) sesión del usuario siempre en marcha (PipeWire corre en ella), aunque nadie entre en la Pi
sudo -n loginctl enable-linger "$USUARIO" || ok=0

# 3) WirePlumber: Bluetooth sin esperar a una sesión «activa» en pantalla (la Pi va sin escritorio)
mkdir -p "$HOME/.config/wireplumber/bluetooth.lua.d" "$HOME/.config/wireplumber/wireplumber.conf.d"
cat > "$HOME/.config/wireplumber/bluetooth.lua.d/80-zf2.lua" <<'EOF'
-- ZephyrosFlight 2: Bluetooth sin sesión gráfica (WirePlumber 0.4, bookworm)
bluez_monitor.properties["with-logind"] = false
-- solo A2DP: el Bluetooth de la Pi no saca sonido en modo manos libres (HFP/HSP)
bluez_monitor.properties["bluez5.roles"] = "[ a2dp_sink a2dp_source ]"
EOF
cat > "$HOME/.config/wireplumber/wireplumber.conf.d/80-zf2.conf" <<'EOF'
# ZephyrosFlight 2: Bluetooth sin sesión gráfica (WirePlumber 0.5 y posteriores)
wireplumber.profiles = {
  main = {
    monitor.bluez.seat-monitoring = disabled
  }
}
# solo A2DP: el Bluetooth de la Pi no saca sonido en modo manos libres (HFP/HSP)
monitor.bluez.properties = {
  bluez5.roles = [ a2dp_sink a2dp_source ]
}
EOF

# 4) el programa encuentra el sonido del usuario (PipeWire) aunque arranque como servicio
sudo -n mkdir -p /etc/systemd/system/zf2-mapa.service.d
sudo -n tee /etc/systemd/system/zf2-mapa.service.d/sonido.conf >/dev/null <<EOF
[Unit]
Wants=user@$UID_U.service
After=user@$UID_U.service bluetooth.service

[Service]
Environment=XDG_RUNTIME_DIR=/run/user/$UID_U
EOF
sudo -n systemctl daemon-reload || true
systemctl --user daemon-reload 2>/dev/null || true
XDG_RUNTIME_DIR=/run/user/$UID_U systemctl --user enable pipewire pipewire-pulse wireplumber 2>/dev/null || true
XDG_RUNTIME_DIR=/run/user/$UID_U systemctl --user restart wireplumber 2>/dev/null || true

# 5) girar el arranque (logo y consola) en pantallas DSI verticales: un programa de root, fijo, que
#    solo cambia panel_orientation en cmdline.txt, y permiso para usarlo sin contraseña
sudo -n tee /usr/local/sbin/zf2-orientacion >/dev/null <<'FIN'
#!/bin/bash
# ZephyrosFlight 2: giro del arranque en pantallas DSI. Uso: zf2-orientacion normal|right_side_up|left_side_up|upside_down
o="$1"
case "$o" in normal|right_side_up|left_side_up|upside_down) ;; *) echo "uso: $0 normal|right_side_up|left_side_up|upside_down"; exit 2;; esac
F=/boot/firmware/cmdline.txt; [ -f "$F" ] || F=/boot/cmdline.txt
con=$(ls /sys/class/drm | sed -n 's/^card[0-9]*-\(DSI-[0-9]*\)$/\1/p' | head -1)
[ -n "$con" ] || { echo "sin pantalla DSI"; exit 0; }
l=$(head -1 "$F" | sed -E 's/ ?video=DSI-[0-9]+:panel_orientation=[a-z_]+//g')
[ "$o" != normal ] && l="$l video=$con:panel_orientation=$o"
cp "$F" "$F.zf2bak" && printf '%s\n' "$l" > "$F.tmp" && mv "$F.tmp" "$F" && sync
echo "arranque: $con $o"
FIN
sudo -n chmod 755 /usr/local/sbin/zf2-orientacion && sudo -n chown root:root /usr/local/sbin/zf2-orientacion || ok=0
echo "$USUARIO ALL=(root) NOPASSWD: /usr/local/sbin/zf2-orientacion" | sudo -n tee /etc/sudoers.d/zf2-orientacion >/dev/null
sudo -n chmod 440 /etc/sudoers.d/zf2-orientacion
sudo -n visudo -cf /etc/sudoers.d/zf2-orientacion >/dev/null || { sudo -n rm -f /etc/sudoers.d/zf2-orientacion; ok=0; }

if [ $ok -eq 1 ]; then
  echo "$VERSION_SISTEMA" > "$CFG/sistema.txt"
  echo "aplicado (se nota al reiniciar)"
else
  echo "incompleto: se repetira en la proxima actualizacion"
fi
exit 0
