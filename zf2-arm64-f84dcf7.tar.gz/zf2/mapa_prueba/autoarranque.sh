#!/bin/bash
# ZephyrosFlight 2 — arranque automático del mapa al encender la Raspberry Pi.
#
#   ./autoarranque.sh si    al encender, sale el mapa (sin escritorio)
#   ./autoarranque.sh no    vuelve a arrancar el escritorio, sin el mapa
#
# Con "si" la Pi arranca en modo consola (sin escritorio): así arranca antes y
# el mapa tiene la pantalla para él solo, como en el avión. El botón SALIR
# cierra el mapa y deja la consola; para volver a abrirlo: sudo systemctl start zf2-mapa
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
USUARIO="$(id -un)"
SERVICIO=/etc/systemd/system/zf2-mapa.service
OPCIONES="${ZF2_OPCIONES:---sim}"     # sin GPS conectado, vuelo simulado

case "$1" in
  si)
    sudo tee "$SERVICIO" > /dev/null <<EOF
[Unit]
Description=ZephyrosFlight 2 - mapa
After=systemd-user-sessions.service
Conflicts=getty@tty1.service

[Service]
User=$USUARIO
SupplementaryGroups=video render input tty dialout i2c
WorkingDirectory=$DIR
Environment=SDL_VIDEODRIVER=kmsdrm
ExecStartPre=+-/bin/sh -c 'command -v plymouth >/dev/null && plymouth quit --retain-splash'
ExecStart=$DIR/mapa_prueba $OPCIONES
Restart=on-failure
RestartSec=2
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF
    # actualización desde GitHub en segundo plano cuando haya red (se aplica al siguiente encendido)
    sudo tee /etc/systemd/system/zf2-actualizar.service > /dev/null <<EOF
[Unit]
Description=ZephyrosFlight 2 - actualizar desde GitHub
Wants=network-online.target
After=network-online.target

[Service]
Type=oneshot
User=$USUARIO
Environment=HOME=$HOME
ExecStart=$DIR/actualizar.sh
TimeoutStartSec=600
Nice=10

[Install]
WantedBy=multi-user.target
EOF
    # portal web para editar aviones y checklists desde el móvil (http://<equipo>:8080)
    sudo tee /etc/systemd/system/zf2-portal.service > /dev/null <<EOF
[Unit]
Description=ZephyrosFlight 2 - portal web (aviones y checklists)
After=network.target

[Service]
User=$USUARIO
Environment=HOME=$HOME
ExecStart=/usr/bin/python3 $DIR/../portal/portal.py
Restart=on-failure
RestartSec=5
Nice=5

[Install]
WantedBy=multi-user.target
EOF
    # bus CAN de los sensores (ESP32-S3): levanta can0 a 500 kbit/s si existe (adaptador USB o HAT)
    sudo tee /etc/systemd/system/zf2-can.service > /dev/null <<EOF
[Unit]
Description=ZephyrosFlight 2 - bus CAN de los sensores
Before=zf2-mapa.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/sh -c 'for i in \$(seq 1 20); do if ip link show can0 >/dev/null 2>&1; then ip link set can0 down; ip link set can0 up type can bitrate 500000 restart-ms 100; exit 0; fi; sleep 1; done; exit 0'

[Install]
WantedBy=multi-user.target
EOF
    # permiso para que el mapa gestione la wifi (AJUSTES > RED) sin contraseña de administrador
    sudo tee /etc/polkit-1/rules.d/50-zf2-red.rules > /dev/null <<EOF
polkit.addRule(function(action, subject) {
  if (action.id.indexOf("org.freedesktop.NetworkManager.") == 0 && subject.user == "$USUARIO") return polkit.Result.YES;
  // APAGAR y REINICIAR desde el programa (INICIO y AJUSTES › SISTEMA)
  if (action.id.indexOf("org.freedesktop.login1.power-off") == 0 && subject.user == "$USUARIO") return polkit.Result.YES;
  if (action.id.indexOf("org.freedesktop.login1.reboot") == 0 && subject.user == "$USUARIO") return polkit.Result.YES;
});
EOF
    sudo raspi-config nonint do_boot_behaviour B1     # consola, sin escritorio
    sudo raspi-config nonint do_i2c 0                 # I2C activado: BNO085 y BMP580 de la caja
    sudo raspi-config nonint do_serial_cons 1         # puerto serie para el GPS, sin la consola encima
    sudo raspi-config nonint do_serial_hw 0
    # Pi 5: el puerto de los pines 8 y 10 (uart0, /dev/ttyAMA0) hay que activarlo aparte
    CFG=/boot/firmware/config.txt; [ -f "$CFG" ] || CFG=/boot/config.txt
    if grep -q "Raspberry Pi 5" /proc/device-tree/model 2>/dev/null && ! grep -q '^dtparam=uart0=on' "$CFG"; then
      echo 'dtparam=uart0=on' | sudo tee -a "$CFG" > /dev/null
    fi
    sudo usermod -aG i2c,dialout "$USUARIO"
    "$DIR/sistema.sh" --forzar || true                # sonido con cascos Bluetooth (PipeWire)
    # pantalla de arranque con el logo y una barra de progreso (en vez de los mensajes del sistema)
    "$DIR/../arranque/instalar_arranque.sh" si || echo "(la pantalla de arranque no se pudo instalar: hace falta internet)"
    sudo systemctl daemon-reload
    sudo systemctl enable zf2-mapa.service zf2-actualizar.service zf2-portal.service zf2-can.service
    sudo systemctl restart zf2-portal.service
    echo
    echo "Listo. Al encender saldra el mapa ($OPCIONES)."
    echo "Reinicia para probarlo:  sudo reboot"
    echo "Ver mensajes del mapa:   journalctl -u zf2-mapa -b"
    echo "Ademas, al encender con red se descarga la ultima version (se usa en el siguiente encendido)."
    echo "Portal de aviones y checklists: http://$(hostname).local:8080"
    ;;
  no)
    sudo systemctl disable --now zf2-mapa.service zf2-actualizar.service zf2-portal.service zf2-can.service 2>/dev/null || true
    sudo rm -f "$SERVICIO" /etc/systemd/system/zf2-actualizar.service /etc/systemd/system/zf2-portal.service /etc/systemd/system/zf2-can.service /etc/polkit-1/rules.d/50-zf2-red.rules
    sudo systemctl daemon-reload
    sudo raspi-config nonint do_boot_behaviour B4     # escritorio
    "$DIR/../arranque/instalar_arranque.sh" no || true
    echo "Quitado. La Pi vuelve a arrancar el escritorio. Reinicia: sudo reboot"
    ;;
  *)
    echo "Uso: $0 si | no"
    exit 1
    ;;
esac
