#!/usr/bin/env python3
"""ZephyrosFlight 2 — portal web para editar los aviones y sus checklists.

Se abre desde el móvil o el ordenador, en la misma red que el equipo:
    http://zephyros.local:8080   (o la IP que sale en AJUSTES > CHECKLISTS)

Lo editado se guarda en ~/.config/zf2/aviones/N/ (N = 1..4). La primera vez que se edita un avión,
se copia allí lo que trae el programa (datos/aviones/N/), así las actualizaciones no pisan tus cambios.
El mapa vuelve a cargar las checklists solo, a los 2 s de guardar.

Solo usa la biblioteca estándar de Python 3.
"""
import html
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PUERTO = int(os.environ.get("ZF2_PORTAL_PUERTO", "8080"))
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATOS = os.environ.get("ZF2_DATOS", os.path.join(RAIZ, "datos"))
USUARIO = os.path.join(os.path.expanduser("~"), ".config", "zf2", "aviones")
CONFIG = os.path.join(os.path.expanduser("~"), ".config", "zf2")      # libro de vuelo y trazas (los escribe el equipo)
MAX_SUBIDA = 30 * 1024 * 1024
CARTAS = os.path.join(CONFIG, "cartas")                               # cartas VAC: imagen + NOMBRE.geo
IMG_EXT = (".jpg", ".jpeg", ".png")

PLANTILLA = """# Plantilla de avión nuevo: rellena los datos y adapta cada punto al MANUAL DE TU AVIÓN.
# Formato: una línea por elemento (ver «Formato» abajo). Las líneas con # no se ven en el equipo.
AVION|EC-XXX|Fabricante y modelo
FOTO|foto.jpg

# Velocidades (pon el número delante de la unidad: km/h, kt o mph).
# Vs0, Vs1, Vfe, Vno y Vne pintan los arcos de la cinta de velocidad del PFD.
DATO|Vs0| km/h
DATO|Vs1| km/h
DATO|Vfe| km/h
DATO|Vno| km/h
DATO|Vne| km/h
DATO|Vr (rotación)| km/h
DATO|Vx (mejor ángulo)| km/h
DATO|Vy (mejor régimen)| km/h
DATO|Mejor planeo| km/h
DATO|Aproximación| km/h
# Otros datos (la fineza la usa el planeo de emergencia; el viento cruzado, la vista del METAR)
DATO|Fineza|1:
DATO|Viento cruzado máx| kt
DATO|MTOW| kg
DATO|Combustible utilizable| l
DATO|Consumo de crucero| l/h
DATO|Aceite|
DATO|Neumáticos| bar

LISTA|1 Prevuelo (exterior)
Documentación y llaves|A BORDO
Interruptores y magnetos|APAGADOS
Combustible (nivel y tapones)|COMPROBAR
Drenaje de combustible|SIN AGUA
Aceite y refrigerante|COMPROBAR
Hélice y capó|SIN DAÑOS
Tren y neumáticos|COMPROBAR
Superficies de mando y bisagras|LIBRES, SIN HOLGURA
Flaps|COMPROBAR
Tubo pitot|DESTAPADO
Anclajes y calzos|QUITADOS

LISTA|2 Antes de arrancar
Cinturones y arneses|AJUSTADOS
Cúpula / puertas|CERRADAS
Frenos|APLICADOS
Mandos|LIBRES
Válvula de combustible|ABIERTA
Altímetro|AJUSTADO (QNH)

LISTA|3 Arranque
Zona de la hélice|DESPEJADA
Bomba eléctrica|CONECTADA
Estárter / mezcla|SEGÚN MANUAL
Interruptor general y magnetos|CONECTADOS
Arranque|ACCIONAR
Presión de aceite|EN VERDE
Radio y transpondedor|CONECTADOS

LISTA|4 Antes del despegue
Temperaturas y presiones|EN VERDE
Prueba de magnetos|CAÍDA DENTRO DE LÍMITES
Flaps|POSICIÓN DE DESPEGUE
Compensador|DESPEGUE
Combustible|DEPÓSITO CORRECTO, BOMBA ON
Instrumentos y GPS|COMPROBADOS
Mandos|LIBRES Y CORRECTOS
Cinturones, cúpula y puertas|CERRADOS
NOTA|Briefing de despegue: qué hacer si falla el motor

LISTA|5 Despegue y ascenso
Potencia|MÁXIMA
Rotación|Vr
Ascenso|Vy
Flaps (a altura segura)|ARRIBA
Bomba eléctrica (a altura segura)|SEGÚN MANUAL

LISTA|6 Crucero
Potencia|CRUCERO
Compensador|AJUSTADO
Combustible y temperaturas|VIGILAR

LISTA|7 Aproximación y aterrizaje
Combustible|DEPÓSITO CORRECTO, BOMBA ON
Altímetro|QNH
Flaps|SEGÚN VELOCIDAD
Velocidad de aproximación|MANTENER
Cinturones|AJUSTADOS

LISTA|8 Después de aterrizar y parada
Flaps|ARRIBA
Bomba eléctrica|DESCONECTADA
Radio y transpondedor|DESCONECTADOS
Magnetos e interruptor general|APAGADOS
Avión|ASEGURADO

LISTA|!Fallo de motor en el despegue
Velocidad de planeo|MANTENER
Aterrizar|DE FRENTE (sin girar más de 30°)
Combustible y magnetos|CERRADOS
Interruptor general|APAGADO (antes de tocar)

LISTA|!Fallo de motor en vuelo
Velocidad de mejor planeo|MANTENER
Campo para aterrizar|ELEGIR
Combustible (depósito, bomba)|COMPROBAR
Magnetos y estárter|COMPROBAR
Rearranque|INTENTAR SI HAY ALTURA
Radio|MAYDAY 121,500 · transpondedor 7700

LISTA|!Fuego en el motor
Combustible|CERRADO
Potencia|MÁXIMA hasta que se pare
Magnetos e interruptor general|APAGADOS
Aterrizaje|DE EMERGENCIA

LISTA|!Aterrizaje de emergencia
Cinturones|AJUSTADOS
Radio|MAYDAY
Combustible y magnetos|CERRADOS (antes de tocar)
Cúpula / puertas|DESBLOQUEADAS
Toma|A VELOCIDAD MÍNIMA
"""


def carpeta(n, escribir=False):
    """Carpeta del avión n: la del usuario si existe; con escribir=True, la crea copiando la original."""
    u = os.path.join(USUARIO, str(n))
    o = os.path.join(DATOS, "aviones", str(n))
    if os.path.isfile(os.path.join(u, "checklist.txt")):
        return u
    if not escribir:
        return o
    os.makedirs(u, exist_ok=True)
    if os.path.isdir(o):
        for f in os.listdir(o):
            src = os.path.join(o, f)
            if os.path.isfile(src) and not os.path.exists(os.path.join(u, f)):
                shutil.copy2(src, os.path.join(u, f))
    return u


def leer(n):
    p = os.path.join(carpeta(n), "checklist.txt")
    try:
        with open(p, encoding="utf-8") as f:
            return f.read()
    except OSError:
        return ""


def resumen(texto):
    reg = modelo = ""
    listas = emerg = 0
    for l in texto.splitlines():
        v = l.rstrip("\r").split("|")
        if v[0] == "AVION":
            reg = v[1] if len(v) > 1 else ""
            modelo = v[2] if len(v) > 2 else ""
        elif v[0] == "LISTA":
            listas += 1
            if len(v) > 1 and v[1].startswith("!"):
                emerg += 1
    return reg, modelo, listas, emerg


def imagenes(n):
    d = carpeta(n)
    try:
        return sorted(f for f in os.listdir(d) if f.lower().endswith(IMG_EXT))
    except OSError:
        return []


def nombre_seguro(nombre):
    base, ext = os.path.splitext(os.path.basename(nombre))
    ext = ext.lower()
    if ext not in IMG_EXT:
        return None
    base = re.sub(r"[^A-Za-z0-9_-]+", "_", base).strip("_")[:40] or "imagen"
    return base + (".jpg" if ext == ".jpeg" else ext)


CSS = """
*{box-sizing:border-box} body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:#101721;color:#e8ecf2}
header{background:#0b1018;padding:14px 18px;border-bottom:1px solid #26344a} header h1{margin:0;font-size:20px}
header a{color:#8cc4ff;text-decoration:none;font-size:15px} main{padding:16px;max-width:1300px;margin:auto}
.card{background:#1a2433;border:1px solid #2b3a52;border-radius:10px;padding:14px;margin-bottom:12px}
.row{display:flex;gap:12px;align-items:center;flex-wrap:wrap} .grow{flex:1}
button,.btn{background:#2a6fd6;color:#fff;border:0;border-radius:8px;padding:11px 16px;font-size:15px;cursor:pointer;text-decoration:none;display:inline-block}
.btn2{background:#2b3a52} .rojo{background:#a52a2a} .verde{background:#1f8a4c}
.dim{color:#93a1b5;font-size:14px} textarea{width:100%;min-height:62vh;background:#0b1018;color:#e8ecf2;border:1px solid #2b3a52;border-radius:8px;padding:10px;font:14px/1.45 ui-monospace,Menlo,Consolas,monospace}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:14px} @media(max-width:900px){.cols{grid-template-columns:1fr} textarea{min-height:45vh}}
.prev h3{margin:14px 0 6px;font-size:16px} .prev .em{color:#ff6b6b} .it{display:flex;justify-content:space-between;gap:10px;border-bottom:1px solid #263449;padding:5px 0;font-size:14px}
.it b{color:#7fd0ff;text-align:right} .sec{color:#ffd166;font-weight:600;margin-top:8px;font-size:13px;text-transform:uppercase}
.nota{background:#3a2f12;border-left:4px solid #ffbf3c;padding:6px 8px;margin:6px 0;font-size:14px} .err{color:#ff8080;font-size:13px}
.imgs{display:flex;gap:10px;flex-wrap:wrap} .imgs figure{margin:0;width:130px;text-align:center;font-size:12px;word-break:break-all}
.imgs img{width:130px;height:90px;object-fit:cover;border-radius:6px;border:1px solid #2b3a52;background:#0b1018}
.ok{position:fixed;bottom:18px;right:18px;background:#1f8a4c;color:#fff;padding:12px 18px;border-radius:8px;display:none}
code{background:#0b1018;padding:1px 5px;border-radius:4px}
"""


def pagina(titulo, cuerpo, volver=True):
    v = '<a href="/">&larr; Aviones</a>' if volver else '<span class="dim">ZephyrosFlight 2</span>'
    return f"""<!doctype html><html lang=es><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1"><title>{html.escape(titulo)}</title><style>{CSS}</style></head>
<body><header><div class=row><h1 class=grow>{html.escape(titulo)}</h1>{v}</div></header><main>{cuerpo}</main></body></html>"""


def inicio():
    c = '<p class=dim>Hasta 4 aviones. Cada uno tiene su ficha (matrícula, datos, documentos) y sus checklists. ' \
        'Los cambios se ven en el equipo a los pocos segundos de guardar.</p>'
    for n in range(1, 5):
        t = leer(n)
        reg, modelo, listas, emerg = resumen(t)
        propio = os.path.isfile(os.path.join(USUARIO, str(n), "checklist.txt"))
        c += '<div class="card row">'
        if reg:
            foto = ""
            for l in t.splitlines():
                if l.startswith("FOTO|"):
                    foto = l.split("|")[1].strip()
            img = f'<img src="/img/{n}/{urllib.parse.quote(foto)}" style="width:110px;height:72px;object-fit:cover;border-radius:6px">' if foto else ""
            c += f'{img}<div class=grow><b style="font-size:18px">{n}. {html.escape(reg)}</b> &nbsp; {html.escape(modelo)}<br>' \
                 f'<span class=dim>{listas} listas ({emerg} de emergencia){" · editado" if propio else " · original"}</span></div>'
            c += f'<a class=btn href="/avion/{n}">Editar</a>'
            if propio and os.path.isdir(os.path.join(DATOS, "aviones", str(n))):
                c += f'<form method=post action="/restaurar/{n}" onsubmit="return confirm(\'¿Volver a la versión original? Se pierden tus cambios de este avión.\')">' \
                     f'<button class="btn2">Restaurar original</button></form>'
        else:
            c += f'<div class=grow><b style="font-size:18px">{n}.</b> <span class=dim>(vacío)</span></div>' \
                 f'<a class="btn verde" href="/avion/{n}?nuevo=1">Añadir avión</a>'
        c += '</div>'
    c += '<div class="card row"><div class=grow><b style="font-size:18px">Libro de vuelo</b><br>' \
         '<span class=dim>Vuelos grabados por el equipo y sus trazas GPX (para SkyDemon, Google Earth…)</span></div>' \
         '<a class=btn href="/vuelos">Ver vuelos</a></div>'
    c += '<div class="card row"><div class=grow><b style="font-size:18px">Cartas VAC</b><br>' \
         '<span class=dim>Sube la carta (PDF, PNG o JPG), marca dos o tres puntos conocidos y el equipo la pone en el mapa con el avión encima</span></div>' \
         '<a class=btn href="/cartas">Cartas</a></div>'
    return pagina("Aviones y checklists", c, volver=False)


# ---------------------------------------------------------------- cartas VAC
def nombre_carta(n):
    n = re.sub(r"[^A-Za-z0-9_-]+", "_", os.path.splitext(os.path.basename(n))[0]).strip("_")[:40]
    return n or "carta"


def imagen_carta(n):
    for ext in (".png", ".jpg", ".jpeg"):
        p = os.path.join(CARTAS, n + ext)
        if os.path.isfile(p):
            return p
    return None


def puntos_carta(n):
    pts, tam = [], None
    try:
        with open(os.path.join(CARTAS, n + ".geo"), encoding="utf-8") as f:
            for l in f:
                if l.startswith("#tam "):
                    tam = [int(x) for x in l.split()[1:3]]
                elif l.strip() and not l.startswith("#"):
                    v = l.split()
                    if len(v) >= 4:
                        pts.append([float(x) for x in v[:4]])
    except (OSError, ValueError):
        pass
    return pts, tam


def lista_cartas():
    try:
        nombres = sorted({os.path.splitext(f)[0] for f in os.listdir(CARTAS) if f.lower().endswith((".png", ".jpg", ".jpeg"))})
    except OSError:
        nombres = []
    return nombres


_UMBRALES = None
_ALIAS = None
_NOMBRES = None


def _cargar_aerodromos():
    global _UMBRALES, _ALIAS, _NOMBRES
    _UMBRALES, _ALIAS, _NOMBRES = {}, {}, {}
    try:
        with open(os.path.join(DATOS, "umbrales.txt"), encoding="utf-8") as f:
            for l in f:
                v = l.rstrip("\n").split("|")
                if len(v) >= 4 and not l.startswith("#"):
                    _UMBRALES.setdefault(v[0].upper(), []).append([v[1], float(v[2]), float(v[3]), v[6] if len(v) > 6 else ""])
    except (OSError, ValueError):
        pass
    for nom, dic in (("alias.txt", _ALIAS), ("aerodromos.txt", _NOMBRES)):
        try:
            with open(os.path.join(DATOS, nom), encoding="utf-8") as f:
                for l in f:
                    v = l.rstrip("\n").split("|")
                    if len(v) >= 2 and not l.startswith("#"):
                        dic[v[0].upper()] = v[1]
        except OSError:
            pass


def umbrales(texto):
    """Aeródromo por su id, por otro indicativo (alias.txt: LETX → ES-0036) o por parte del nombre:
    {"id", "nombre", "umbrales": [[pista, lat, lon, fuente], …]}"""
    if _UMBRALES is None:
        _cargar_aerodromos()
    t = texto.strip().upper()
    ident = t if t in _NOMBRES else _ALIAS.get(t)
    if not ident and len(t) >= 3:                           # por el nombre: «Totana»
        for k, n in _NOMBRES.items():
            if t in n.upper() and k in _UMBRALES:
                ident = k
                break
    if not ident:
        return {"id": "", "nombre": "", "umbrales": []}
    return {"id": ident, "nombre": _NOMBRES.get(ident, ""), "umbrales": _UMBRALES.get(ident, [])}


def cartas():
    c = '<p class=dim>Las cartas VAC (o cualquier plano o imagen) se dibujan en el mapa del equipo, con el avión encima, ' \
        'en cuanto tienen <b>dos o más puntos</b> marcados (mejor tres, separados). Se activan o quitan en el equipo en ' \
        'MENU › Cartas VAC. Un PDF de varias páginas se convierte en una carta por página: georreferencia la que sea el mapa.</p>'
    c += '<div class="card row"><b class=grow>Subir una carta</b>' \
         '<label class="btn verde">Elegir PDF, PNG o JPG<input type=file accept="application/pdf,image/png,image/jpeg" hidden onchange="subir(this)"></label></div>'
    nombres = lista_cartas()
    if not nombres:
        c += '<div class=card>Todavía no hay cartas.</div>'
    for n in nombres:
        pts, _ = puntos_carta(n)
        est = f'<span style="color:#5fd38d">{len(pts)} puntos: en el mapa</span>' if len(pts) >= 2 else \
              '<span style="color:#ffbf3c">sin georreferenciar</span>'
        q = urllib.parse.quote(n)
        c += f'<div class="card row"><img src="/cartaimg/{q}" style="width:90px;height:120px;object-fit:cover;border-radius:6px;background:#fff">' \
             f'<div class=grow><b style="font-size:18px">{html.escape(n)}</b><br>{est}</div>' \
             f'<a class=btn href="/carta/{q}">Marcar puntos</a>' \
             f'<form method=post action="/cartaborrar/{q}" onsubmit="return confirm(\'¿Borrar la carta {html.escape(n)}?\')">' \
             f'<button class="rojo">Borrar</button></form></div>'
    c += '<div class=ok id=ok></div><script>' + r"""
function aviso(t){const o=document.getElementById('ok');o.textContent=t;o.style.display='block';setTimeout(()=>o.style.display='none',4000)}
async function subirUno(nombre,cuerpo){const r=await fetch('/cartasubir?nombre='+encodeURIComponent(nombre),{method:'POST',body:cuerpo});
 if(!r.ok)throw new Error(await r.text());return (await r.json()).cartas}
// los PDF se convierten aquí, en el navegador (pdf.js): una imagen PNG por página, como mucho 3000 píxeles de lado
async function pdfAPng(f){aviso('Preparando el PDF…');
 if(!window.pdfjsLib){await new Promise((ok,mal)=>{const s=document.createElement('script');s.src='/estatico/pdf.min.js';s.onload=ok;s.onerror=mal;document.head.appendChild(s)})}
 pdfjsLib.GlobalWorkerOptions.workerSrc='/estatico/pdf.worker.min.js';
 const doc=await pdfjsLib.getDocument({data:await f.arrayBuffer()}).promise,n=Math.min(doc.numPages,12),base=f.name.replace(/\.pdf$/i,''),hechas=[];
 for(let i=1;i<=n;i++){aviso(`Convirtiendo la página ${i} de ${n}…`);const pg=await doc.getPage(i),v0=pg.getViewport({scale:1});
  const k=Math.min(200/72,3000/Math.max(v0.width,v0.height)),v=pg.getViewport({scale:k});
  const c=document.createElement('canvas');c.width=Math.round(v.width);c.height=Math.round(v.height);const g=c.getContext('2d');
  g.fillStyle='#fff';g.fillRect(0,0,c.width,c.height);await pg.render({canvasContext:g,viewport:v}).promise;
  const b=await new Promise(ok=>c.toBlob(ok,'image/png'));hechas.push(...await subirUno(n==1?base+'.png':`${base}_p${i}.png`,b))}
 return hechas}
async function subir(inp){const f=inp.files[0];if(!f)return;if(f.size>30e6){aviso('Demasiado grande (máx. 30 MB)');return}
 try{let hechas;
  if(/\.pdf$/i.test(f.name)||f.type=='application/pdf')hechas=await pdfAPng(f);
  else{aviso('Subiendo '+f.name+'…');hechas=await subirUno(f.name,f)}
  location.href=hechas.length==1?'/carta/'+encodeURIComponent(hechas[0]):'/cartas'}
 catch(e){aviso('Error: '+(e.message||e))}}""" + '</script>'
    return pagina("Cartas VAC", c)


GEO_JS = r"""
const im=document.getElementById('im'),cv=document.getElementById('cv'),caja=document.getElementById('caja'),NOM=caja.dataset.n;
let pts=JSON.parse(caja.dataset.p),zoom=1,sel=-1;
const MLA=110540,MLO=111320;
function parse(s){s=(s||'').trim().toUpperCase().replace(',','.');if(!s)return NaN;
 let neg=/[SWO]$/.test(s)||/^[SWO]/.test(s)||s.startsWith('-');s=s.replace(/[NSEWO]/g,' ').replace(/^-/,'');
 const m=s.match(/[0-9.]+/g);if(!m)return NaN;let v;
 if(m.length==1&&/^\d{6,7}(\.\d+)?$/.test(m[0])){const t=m[0];const k=t.indexOf('.')>=0?t.indexOf('.'):t.length;const ss=t.slice(k-2),mm=t.slice(k-4,k-2),dd=t.slice(0,k-4);v=+dd+mm/60+ss/3600}
 else v=(+m[0])+(m[1]?m[1]/60:0)+(m[2]?m[2]/3600:0);return neg?-v:v}
function ajuste(){const ok=pts.filter(p=>isFinite(p[2])&&isFinite(p[3]));if(ok.length<2)return null;
 let la0=0,lo0=0;ok.forEach(p=>{la0+=p[2];lo0+=p[3]});la0/=ok.length;lo0/=ok.length;const kx=Math.cos(la0*Math.PI/180);
 const q=ok.map(p=>[p[0],p[1],(p[3]-lo0)*MLO*kx,(p[2]-la0)*MLA]);
 let mu=0,mv=0,mx=0,my=0;q.forEach(p=>{mu+=p[0];mv+=p[1];mx+=p[2];my+=p[3]});mu/=q.length;mv/=q.length;mx/=q.length;my/=q.length;
 let S=0,sr=0,si=0;q.forEach(p=>{const u=p[0]-mu,v=p[1]-mv,x=p[2]-mx,y=p[3]-my;S+=u*u+v*v;sr+=x*u-y*v;si+=x*v+y*u});if(S<1)return null;
 const br=sr/S,bi=si/S,a=[mx-br*mu-bi*mv,br,bi,my-bi*mu+br*mv,bi,-br];
 const res=q.map(p=>Math.hypot(a[0]+a[1]*p[0]+a[2]*p[1]-p[2],a[3]+a[4]*p[0]+a[5]*p[1]-p[3]));
 const esc=Math.sqrt(Math.abs(a[1]*a[5]-a[2]*a[4]));return {res,esc,ok}}
function dibujar(){cv.width=im.naturalWidth*zoom;cv.height=im.naturalHeight*zoom;const g=cv.getContext('2d');g.drawImage(im,0,0,cv.width,cv.height);
 pts.forEach((p,i)=>{const x=p[0]*zoom,y=p[1]*zoom;g.lineWidth=3;g.strokeStyle=i==sel?'#ff2d55':'#0a84ff';g.beginPath();g.arc(x,y,14,0,7);g.stroke();
  g.beginPath();g.moveTo(x-22,y);g.lineTo(x+22,y);g.moveTo(x,y-22);g.lineTo(x,y+22);g.stroke();g.font='bold 20px sans-serif';g.fillStyle=g.strokeStyle;g.fillText(i+1,x+16,y-14)});
 const A=ajuste();let h='';
 pts.forEach((p,i)=>{h+=`<div class="card row" style="padding:8px;${i==sel?'border-color:#ff2d55':''}" onclick="if(sel!=${i}){sel=${i};dibujar()}"><b>${i+1}</b>
  <span class=dim>(${Math.round(p[0])}, ${Math.round(p[1])})</span>
  <input onclick="event.stopPropagation()" placeholder="latitud (37.7935 o 37 47 37N)" value="${isFinite(p[2])?p[2].toFixed(6):''}" onchange="pts[${i}][2]=parse(this.value);dibujar()" style="width:190px">
  <input onclick="event.stopPropagation()" placeholder="longitud (-1.1371 o 001 08 14W)" value="${isFinite(p[3])?p[3].toFixed(6):''}" onchange="pts[${i}][3]=parse(this.value);dibujar()" style="width:190px">
  ${umb.length?`<select onclick="event.stopPropagation()" onchange="if(this.value){const u=umb[this.value];pts[${i}][2]=u[1];pts[${i}][3]=u[2];dibujar()}"><option value="">umbral de pista…</option>${umb.map((u,k)=>`<option value=${k}${Math.abs(p[2]-u[1])<1e-6&&Math.abs(p[3]-u[2])<1e-6?' selected':''}>${ID} ${u[0]}${u[3]=='a'?' (aprox.)':''}</option>`).join('')}</select>`:''}
  <span class=dim>${A&&A.ok.includes(p)&&A.ok.length>2?'error '+Math.round(A.res[A.ok.indexOf(p)])+' m':''}</span>
  <button class=rojo onclick="event.stopPropagation();pts.splice(${i},1);sel=-1;dibujar()">Quitar</button></div>`});
 document.getElementById('lista').innerHTML=h||'<p class=dim>Toca en la carta un punto que conozcas (el umbral de una pista, un cruce de la cuadrícula de coordenadas…).</p>';
 document.getElementById('est').innerHTML=!A?'<span style=color:#ffbf3c>Faltan puntos con coordenadas (mínimo 2)</span>':
  `<span style=color:#5fd38d>Escala ${A.esc.toFixed(2)} m por píxel</span>`+(A.ok.length>2?` · error medio ${Math.round(A.res.reduce((a,b)=>a+b,0)/A.res.length)} m`:' · con 3 puntos se ve el error')}
cv.addEventListener('click',e=>{const r=cv.getBoundingClientRect();const x=(e.clientX-r.left)*cv.width/r.width/zoom,y=(e.clientY-r.top)*cv.height/r.height/zoom;
 for(let i=0;i<pts.length;i++)if(Math.hypot(pts[i][0]-x,pts[i][1]-y)<20/zoom){sel=i;dibujar();return}
 if(sel>=0&&!(isFinite(pts[sel][2])&&isFinite(pts[sel][3]))){pts[sel][0]=x;pts[sel][1]=y}else{pts.push([x,y,NaN,NaN]);sel=pts.length-1}dibujar()});
function zm(k){const c=caja,cx=(c.scrollLeft+c.clientWidth/2)/zoom,cy=(c.scrollTop+c.clientHeight/2)/zoom;zoom=Math.max(0.1,Math.min(4,zoom*k));dibujar();
 c.scrollLeft=cx*zoom-c.clientWidth/2;c.scrollTop=cy*zoom-c.clientHeight/2}
function aviso(t){const o=document.getElementById('ok');o.textContent=t;o.style.display='block';setTimeout(()=>o.style.display='none',3000)}
async function guardar(){const ok=pts.filter(p=>isFinite(p[2])&&isFinite(p[3]));
 const r=await fetch('/cartapuntos/'+encodeURIComponent(NOM),{method:'POST',body:JSON.stringify({w:im.naturalWidth,h:im.naturalHeight,p:ok,ad:ADID})});
 aviso(r.ok?(ok.length>=2?'Guardada: el equipo la pone en el mapa en unos segundos':'Guardada (sin georreferenciar todavía)'):'Error al guardar')}
let ID=caja.dataset.id,umb=[],ADID='';
async function cargarUmb(id){const r=await fetch('/umbrales/'+encodeURIComponent(id.trim()));const j=r.ok?await r.json():{umbrales:[]};
 umb=j.umbrales;ID=j.id||id.toUpperCase();ADID=j.id||'';const ap=umb.some(u=>u[3]=='a');
 document.getElementById('adinfo').innerHTML=!id.trim()?'':!j.id?`<span style=color:#ffbf3c>No encuentro «${esc(id)}»: escribe las coordenadas a mano</span>`:
  !umb.length?`${esc(j.nombre)} (${esc(j.id)}): sin umbrales conocidos, escribe las coordenadas a mano`:
  `${esc(j.nombre)} (${esc(j.id)}): ${umb.length} umbrales en el desplegable de cada punto`+(ap?' <span style=color:#ffbf3c>(aproximados: añade un tercer punto para comprobar)</span>':'');
 dibujar()}
function esc(s){return String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))}
im.onload=()=>{zoom=Math.min(1,caja.clientWidth/im.naturalWidth);dibujar();if(ID)cargarUmb(ID)};if(im.complete&&im.naturalWidth)im.onload();
"""


def carta(n):
    pts, _ = puntos_carta(n)
    q = urllib.parse.quote(n)
    ident = ""                                              # el aeródromo, en cualquier parte del nombre
    for tok in re.split(r"[_ .]+", n):
        if len(tok) >= 3 and umbrales(tok)["id"]:
            ident = tok.upper()
            break
    c = '<p class=dim>Toca en la carta un punto cuyas coordenadas conozcas y escríbelas (o elige el umbral de una pista ' \
        'del aeródromo). Con <b>2 puntos</b> ya se coloca; con <b>3 o más</b>, bien separados (por ejemplo los dos umbrales y un ' \
        'punto de notificación o un cruce de la cuadrícula), se reparte el error y se ve el de cada punto: si uno pasa de 50 m, revísalo. Para mover un punto, ' \
        'tócalo y vuelve a tocar donde va (antes de darle coordenadas). No es una carta oficial: comprueba siempre.</p>'
    c += f'<div class="card row"><button class=verde onclick="guardar()">Guardar</button>' \
         f'<button class=btn2 onclick="zm(1.4)">Acercar</button><button class=btn2 onclick="zm(1/1.4)">Alejar</button>' \
         f'<span>Aeródromo <input id=ida value="{html.escape(ident)}" maxlength=10 style="width:90px" onchange="cargarUmb(this.value)"></span>' \
         f'<span id=adinfo class=dim></span><span id=est class="grow" style="text-align:right"></span></div>'
    c += f'<div class=cols style="grid-template-columns:2fr 1fr"><div id=caja data-n="{html.escape(n)}" data-id="{html.escape(ident)}" ' \
         f'data-p=\'{html.escape(json.dumps(pts))}\' style="overflow:auto;max-height:78vh;border:1px solid #2b3a52;border-radius:8px;background:#fff">' \
         f'<canvas id=cv style="display:block;cursor:crosshair"></canvas></div><div id=lista></div></div>' \
         f'<img id=im src="/cartaimg/{q}" hidden><div class=ok id=ok></div><script>{GEO_JS}</script>'
    return pagina(f"Carta {n}", c)


def subir_carta(nombre, datos):
    os.makedirs(CARTAS, exist_ok=True)
    base = nombre_carta(nombre)
    ext = os.path.splitext(nombre)[1].lower()
    if datos[:4] == b"%PDF" or ext == ".pdf":
        if not shutil.which("pdftoppm"):
            return None, "Este equipo no puede abrir PDF todavía (falta pdftoppm). Sube la carta como PNG o JPG."
        with tempfile.TemporaryDirectory() as t:
            pdf = os.path.join(t, "c.pdf")
            with open(pdf, "wb") as f:
                f.write(datos)
            # 200 ppp, como mucho 3000 píxeles de lado (la GPU de la Pi admite 4096) y 12 páginas
            r = subprocess.run(["pdftoppm", "-png", "-r", "200", "-scale-to", "3000", "-l", "12", pdf, os.path.join(t, "p")],
                               capture_output=True, timeout=180)
            pags = sorted(f for f in os.listdir(t) if f.startswith("p") and f.endswith(".png"))
            if r.returncode != 0 or not pags:
                return None, "No se ha podido convertir el PDF"
            hechas = []
            for i, f in enumerate(pags):
                n = base if len(pags) == 1 else f"{base}_p{i + 1}"
                shutil.move(os.path.join(t, f), os.path.join(CARTAS, n + ".png"))
                hechas.append(n)
            return hechas, None
    if datos[:8] == b"\x89PNG\r\n\x1a\n":
        ext = ".png"
    elif datos[:3] == b"\xff\xd8\xff":
        ext = ".jpg"
    else:
        return None, "Solo PDF, PNG o JPG"
    for e in (".png", ".jpg", ".jpeg"):                 # una sola imagen por nombre
        if os.path.isfile(os.path.join(CARTAS, base + e)):
            os.remove(os.path.join(CARTAS, base + e))
    with open(os.path.join(CARTAS, base + ext), "wb") as f:
        f.write(datos)
    return [base], None


def vuelos():
    """Libro de vuelo: ~/.config/zf2/libro.txt (una línea por vuelo) y ~/.config/zf2/trazas/*.gpx"""
    filas = []
    try:
        with open(os.path.join(CONFIG, "libro.txt"), encoding="utf-8") as f:
            for l in f:
                v = l.rstrip("\n").split("|")
                if len(v) >= 10 and not l.startswith("#"):
                    filas.append(v)
    except OSError:
        pass
    total = sum(int(v[5]) for v in filas if v[5].isdigit())
    c = f'<p class=dim>{len(filas)} vuelos · total {total // 60}:{total % 60:02d} h</p>'
    if not filas:
        c += '<div class=card>Todavía no hay vuelos grabados. El equipo graba solo cada vuelo, del despegue al aterrizaje.</div>'
    c += '<div class=card><table style="width:100%;border-collapse:collapse">'
    c += '<tr class=dim><td>Fecha</td><td>Ruta</td><td>Despegue</td><td>Aterrizaje</td><td>Tiempo</td><td>Dist.</td><td>Avión</td><td></td></tr>'
    for v in reversed(filas):
        m = int(v[5]) if v[5].isdigit() else 0
        gpx = os.path.basename(v[9])
        enl = f'<a href="/traza/{urllib.parse.quote(gpx)}">GPX</a>' if gpx and os.path.isfile(os.path.join(CONFIG, "trazas", gpx)) else ""
        c += f'<tr style="border-top:1px solid #2a3240"><td>{html.escape(v[0])}</td><td>{html.escape(v[1])} → {html.escape(v[2])}</td>' \
             f'<td>{html.escape(v[3])}</td><td>{html.escape(v[4])}</td><td>{m // 60}:{m % 60:02d}</td><td>{html.escape(v[6])} NM</td>' \
             f'<td>{html.escape(v[8])}</td><td>{enl}</td></tr>'
    c += '</table></div>'
    return pagina("Libro de vuelo", c)


AYUDA = """<details class=card><summary><b>Formato</b> (una línea por elemento)</summary><p class=dim>
<code>AVION|matrícula|modelo</code> · <code>FOTO|archivo</code> · <code>DATO|nombre|valor</code> (sale en la ficha; <code>DATO|Fineza|1:10</code> la usa el planeo de emergencia; <code>DATO|Vs0</code>, <code>Vs1</code>, <code>Vfe</code>, <code>Vno</code> y <code>Vne</code> pintan los arcos de la cinta de velocidad del PFD, en km/h, kt o mph)<br>
<code>DOC|título|archivo</code> documento (gráfica, tabla…) · <code>LISTA|nombre</code> empieza una lista; si el nombre empieza por <code>!</code> es de <span style=color:#ff6b6b>emergencia</span><br>
<code>texto|acción</code> un punto de la lista · <code>SECCION|texto</code> subtítulo · <code>NOTA|texto</code> aviso destacado · <code>IMAGEN|archivo</code> imagen dentro de la lista<br>
Las líneas que empiezan por <code>#</code> son comentarios. Las imágenes se suben abajo y se usan por su nombre.</p></details>"""

JS = r"""
const ta=document.getElementById('t'), pv=document.getElementById('pv'), N=ta.dataset.n;
function esc(s){return s.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))}
function prev(){let h='',enLista=false,errs=[];const ls=ta.value.split('\n');let ficha='';
 ls.forEach((l,i)=>{l=l.replace(/\r$/,'');if(!l.trim()||l[0]=='#')return;const v=l.split('|');const k=v[0];
  if(k=='AVION'){ficha+=`<h3>${esc(v[1]||'')} <span class=dim>${esc(v[2]||'')}</span></h3>`}
  else if(k=='FOTO'){ficha+=`<img src="/img/${N}/${encodeURIComponent((v[1]||'').trim())}" style="max-width:220px;border-radius:6px">`}
  else if(k=='DATO'){ficha+=`<div class=it><span>${esc(v[1]||'')}</span><b>${esc(v[2]||'')}</b></div>`}
  else if(k=='DOC'){ficha+=`<div class=it><span>📄 ${esc(v[1]||'')}</span><span class=dim>${esc(v[2]||'')}</span></div>`}
  else if(k=='LISTA'){const n=v[1]||'';const em=n.startsWith('!');h+=`<h3 class="${em?'em':''}">${esc(em?n.slice(1):n)}${em?' (emergencia)':''}</h3>`;enLista=true}
  else if(!enLista){errs.push(`línea ${i+1}: «${esc(l.slice(0,40))}» está fuera de una LISTA`)}
  else if(k=='SECCION'){h+=`<div class=sec>${esc(v[1]||'')}</div>`}
  else if(k=='NOTA'){h+=`<div class=nota>${esc(v[1]||'')}</div>`}
  else if(k=='IMAGEN'){h+=`<img src="/img/${N}/${encodeURIComponent((v[1]||'').trim())}" style="max-width:100%;border-radius:6px">`}
  else{h+=`<div class=it><span>${esc(v[0])}</span><b>${esc(v.slice(1).join('|'))}</b></div>`}});
 pv.innerHTML=ficha+(errs.length?'<p class=err>'+errs.join('<br>')+'</p>':'')+h}
// matrícula y modelo: casillas enlazadas con la línea AVION|matrícula|modelo del texto
const mReg=document.getElementById('mreg'),mMod=document.getElementById('mmod');
function leerAvion(){const l=ta.value.split('\n').find(x=>x.startsWith('AVION|'));const v=l?l.split('|'):[];
 if(document.activeElement!==mReg)mReg.value=v[1]||'';if(document.activeElement!==mMod)mMod.value=v[2]||''}
function ponerAvion(){const nueva='AVION|'+mReg.value.trim().toUpperCase()+'|'+mMod.value.trim();const ls=ta.value.split('\n');
 const i=ls.findIndex(x=>x.startsWith('AVION|'));if(i>=0)ls[i]=nueva;else{let k=0;while(k<ls.length&&ls[k].startsWith('#'))k++;ls.splice(k,0,nueva)}
 ta.value=ls.join('\n');prev()}
mReg.addEventListener('input',()=>{const p=mReg.selectionStart;mReg.value=mReg.value.toUpperCase();mReg.selectionStart=mReg.selectionEnd=p;ponerAvion()});
mMod.addEventListener('input',ponerAvion);
ta.addEventListener('input',()=>{prev();leerAvion()});prev();leerAvion();
function ins(s){const p=ta.selectionStart;ta.value=ta.value.slice(0,p)+s+ta.value.slice(p);ta.focus();ta.selectionStart=ta.selectionEnd=p+s.length;prev()}
function aviso(t){const o=document.getElementById('ok');o.textContent=t;o.style.display='block';setTimeout(()=>o.style.display='none',2500)}
async function guardar(){const r=await fetch('/guardar/'+N,{method:'POST',headers:{'Content-Type':'text/plain; charset=utf-8'},body:ta.value});
 aviso(r.ok?'Guardado. El equipo lo carga en unos segundos.':'Error al guardar')}
async function subir(inp){for(const f of inp.files){if(f.size>12e6){aviso('Imagen demasiado grande (máx. 12 MB)');continue}
 const r=await fetch('/subir/'+N+'?nombre='+encodeURIComponent(f.name),{method:'POST',body:f});
 if(r.ok){const j=await r.json();aviso('Subida: '+j.nombre);setTimeout(()=>location.reload(),900)}else aviso('Error al subir '+f.name)}}
"""


def editor(n, nuevo):
    t = leer(n)
    if nuevo and not t.strip():
        t = PLANTILLA
    imgs = imagenes(n)
    gal = "".join(
        f'<figure><img src="/img/{n}/{urllib.parse.quote(f)}" loading=lazy><figcaption>{html.escape(f)}<br>'
        f'<a href="#" onclick="ins(\'IMAGEN|{html.escape(f)}\\n\');return false" style="color:#8cc4ff">insertar</a></figcaption></figure>'
        for f in imgs) or '<span class=dim>Todavía no hay imágenes.</span>'
    c = AYUDA
    c += '<div class="card row"><label><b>Matrícula</b> <input id=mreg maxlength=12 placeholder="EC-ABC" ' \
         'style="width:140px;font-size:18px;padding:8px;text-transform:uppercase"></label>' \
         '<label class=grow><b>Modelo</b> <input id=mmod maxlength=60 placeholder="Fabricante y modelo" ' \
         'style="width:70%;font-size:18px;padding:8px"></label>' \
         '<span class=dim>Pulsa Guardar después de cambiarlos</span></div>'
    c += '<div class="card row">' \
         '<button onclick="guardar()" class=verde>Guardar</button>' \
         '<button class=btn2 onclick="ins(\'\\nLISTA|Nueva lista\\nPunto|ACCIÓN\\n\')">+ Lista</button>' \
         '<button class=btn2 onclick="ins(\'\\nLISTA|!Emergencia\\nPunto|ACCIÓN\\n\')">+ Emergencia</button>' \
         '<button class=btn2 onclick="ins(\'Punto|ACCIÓN\\n\')">+ Punto</button>' \
         '<button class=btn2 onclick="ins(\'SECCION|Subtítulo\\n\')">+ Sección</button>' \
         '<button class=btn2 onclick="ins(\'NOTA|Aviso importante\\n\')">+ Nota</button>' \
         '<button class=btn2 onclick="ins(\'DATO|Nombre|valor\\n\')">+ Dato</button>' \
         '<button class=btn2 onclick="ins(\'DATO|Vs0| km/h\\nDATO|Vs1| km/h\\nDATO|Vfe| km/h\\nDATO|Vno| km/h\\nDATO|Vne| km/h\\n\')">+ Velocidades PFD</button>' \
         '<span class="dim grow" style=text-align:right>Avión ' + str(n) + '</span></div>'
    c += f'<div class=cols><div><textarea id=t data-n="{n}" spellcheck=false>{html.escape(t)}</textarea></div>' \
         f'<div class="card prev" id=pv></div></div>'
    c += f'<div class=card><div class=row><b class=grow>Imágenes de este avión</b>' \
         f'<label class=btn>Subir imagen (JPG o PNG)<input type=file accept="image/jpeg,image/png" multiple hidden onchange="subir(this)"></label></div>' \
         f'<p class=dim>Para la foto de la ficha usa <code>FOTO|nombre</code>; para un documento, <code>DOC|título|nombre</code>.</p>' \
         f'<div class=imgs>{gal}</div></div><div class=ok id=ok></div><script>{JS}</script>'
    reg = resumen(t)[0]
    return pagina(f"Avión {n}" + (f" · {reg}" if reg else ""), c)


class Portal(BaseHTTPRequestHandler):
    server_version = "ZF2Portal/1"

    def log_message(self, fmt, *args):
        sys.stderr.write("portal: " + (fmt % args) + "\n")

    def enviar(self, code, cuerpo, tipo="text/html; charset=utf-8", extra=None):
        b = cuerpo.encode("utf-8") if isinstance(cuerpo, str) else cuerpo
        self.send_response(code)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(b)))
        if "Cache-Control" not in (extra or {}):
            self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(b)

    def num(self, parte):
        try:
            n = int(parte)
        except ValueError:
            return None
        return n if 1 <= n <= 4 else None

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        partes = [urllib.parse.unquote(p) for p in u.path.split("/") if p]
        q = urllib.parse.parse_qs(u.query)
        if not partes:
            return self.enviar(200, inicio())
        if partes[0] == "avion" and len(partes) == 2 and self.num(partes[1]):
            return self.enviar(200, editor(self.num(partes[1]), "nuevo" in q))
        if partes[0] == "vuelos" and len(partes) == 1:
            return self.enviar(200, vuelos())
        if partes[0] == "traza" and len(partes) == 2:
            nom = os.path.basename(partes[1])
            p = os.path.join(CONFIG, "trazas", nom)
            if nom.endswith(".gpx") and os.path.isfile(p):
                with open(p, "rb") as f:
                    data = f.read()
                return self.enviar(200, data, "application/gpx+xml", {"Content-Disposition": f'attachment; filename="{nom}"'})
            return self.enviar(404, "no existe", "text/plain")
        if partes[0] == "estatico" and len(partes) == 2:      # pdf.js (convertir los PDF en el navegador)
            nom = os.path.basename(partes[1])
            p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "estatico", nom)
            if nom.endswith(".js") and os.path.isfile(p):
                with open(p, "rb") as f:
                    data = f.read()
                return self.enviar(200, data, "text/javascript; charset=utf-8", {"Cache-Control": "max-age=86400"})
            return self.enviar(404, "no existe", "text/plain")
        if partes[0] == "cartas" and len(partes) == 1:
            return self.enviar(200, cartas())
        if partes[0] == "carta" and len(partes) == 2 and imagen_carta(nombre_carta(partes[1])):
            return self.enviar(200, carta(nombre_carta(partes[1])))
        if partes[0] == "cartaimg" and len(partes) == 2:
            p = imagen_carta(nombre_carta(partes[1]))
            if p:
                with open(p, "rb") as f:
                    data = f.read()
                return self.enviar(200, data, "image/png" if p.endswith(".png") else "image/jpeg")
            return self.enviar(404, "no existe", "text/plain")
        if partes[0] == "umbrales" and len(partes) == 2:
            return self.enviar(200, json.dumps(umbrales(partes[1][:40])), "application/json")
        if partes[0] == "img" and len(partes) == 3 and self.num(partes[1]):
            nom = os.path.basename(partes[2])
            p = os.path.join(carpeta(self.num(partes[1])), nom)
            if nom.lower().endswith(IMG_EXT) and os.path.isfile(p):
                with open(p, "rb") as f:
                    data = f.read()
                return self.enviar(200, data, "image/png" if nom.lower().endswith(".png") else "image/jpeg")
            return self.enviar(404, "no existe", "text/plain")
        self.enviar(404, pagina("No encontrado", "<p>Esa página no existe.</p>"))

    def leer_cuerpo(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_SUBIDA:
            return None
        return self.rfile.read(n)

    def do_POST(self):
        u = urllib.parse.urlparse(self.path)
        partes = [urllib.parse.unquote(p) for p in u.path.split("/") if p]
        if partes and partes[0] in ("cartasubir", "cartapuntos", "cartaborrar"):
            return self.post_carta(u, partes)
        if len(partes) != 2 or not self.num(partes[1]):
            return self.enviar(404, "no", "text/plain")
        n = self.num(partes[1])
        cuerpo = self.leer_cuerpo()
        if cuerpo is None:
            return self.enviar(413, "demasiado grande", "text/plain")
        if partes[0] == "guardar":
            try:
                texto = cuerpo.decode("utf-8")
            except UnicodeDecodeError:
                return self.enviar(400, "texto no válido", "text/plain")
            texto = texto.replace("\r\n", "\n")
            d = carpeta(n, escribir=True)
            p = os.path.join(d, "checklist.txt")
            if os.path.isfile(p):
                shutil.copy2(p, os.path.join(d, "checklist.bak"))     # copia de lo anterior
            tmp = p + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(texto if texto.endswith("\n") else texto + "\n")
            os.replace(tmp, p)                                       # de una vez: el mapa nunca lee medio archivo
            return self.enviar(200, "ok", "text/plain")
        if partes[0] == "subir":
            nom = nombre_seguro(urllib.parse.parse_qs(u.query).get("nombre", ["imagen.jpg"])[0])
            if not nom:
                return self.enviar(400, "solo JPG o PNG", "text/plain")
            d = carpeta(n, escribir=True)
            if not os.path.isfile(os.path.join(d, "checklist.txt")):
                with open(os.path.join(d, "checklist.txt"), "w", encoding="utf-8") as f:
                    f.write(PLANTILLA)
            with open(os.path.join(d, nom), "wb") as f:
                f.write(cuerpo)
            return self.enviar(200, json.dumps({"nombre": nom}), "application/json")
        if partes[0] == "restaurar":
            u_dir = os.path.join(USUARIO, str(n))
            if os.path.isdir(u_dir):
                shutil.rmtree(u_dir)
            return self.enviar(303, "", "text/plain", {"Location": "/"})
        self.enviar(404, "no", "text/plain")


def _post_carta(self, u, partes):
    cuerpo = self.leer_cuerpo()
    if cuerpo is None:
        return self.enviar(413, "demasiado grande (máx. 30 MB)", "text/plain")
    if partes[0] == "cartasubir":
        nom = urllib.parse.parse_qs(u.query).get("nombre", ["carta.png"])[0]
        hechas, err = subir_carta(nom, cuerpo)
        if err:
            return self.enviar(400, err, "text/plain; charset=utf-8")
        return self.enviar(200, json.dumps({"cartas": hechas}), "application/json")
    if len(partes) != 2:
        return self.enviar(404, "no", "text/plain")
    n = nombre_carta(partes[1])
    if not imagen_carta(n):
        return self.enviar(404, "no existe", "text/plain")
    if partes[0] == "cartapuntos":
        try:
            j = json.loads(cuerpo.decode("utf-8"))
            w, h = int(j["w"]), int(j["h"])
            pts = [[float(v) for v in p[:4]] for p in j["p"]]
        except (ValueError, KeyError, TypeError):
            return self.enviar(400, "datos no válidos", "text/plain")
        geo = os.path.join(CARTAS, n + ".geo")
        if len(pts) < 2:                                   # sin georreferenciar: el equipo no la dibuja
            if os.path.isfile(geo):
                os.remove(geo)
            return self.enviar(200, "ok", "text/plain")
        tmp = geo + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(f"# carta {n}: píxel x, píxel y, latitud, longitud (lo escribe el portal)\n#tam {w} {h}\n")
            if re.fullmatch(r"[A-Za-z0-9-]{3,12}", str(j.get("ad", ""))):
                f.write(f"#ad {j['ad']}\n")               # el aeródromo elegido (para la ficha del equipo)
            for p in pts:
                f.write(f"{p[0]:.1f} {p[1]:.1f} {p[2]:.7f} {p[3]:.7f}\n")
        os.replace(tmp, geo)
        return self.enviar(200, "ok", "text/plain")
    if partes[0] == "cartaborrar":
        for e in (".png", ".jpg", ".jpeg", ".geo"):
            if os.path.isfile(os.path.join(CARTAS, n + e)):
                os.remove(os.path.join(CARTAS, n + e))
        return self.enviar(303, "", "text/plain", {"Location": "/cartas"})
    return self.enviar(404, "no", "text/plain")


Portal.post_carta = _post_carta


def vigilar_actualizacion():
    """Tras una actualización, el portal se vuelve a cargar solo (sin reiniciar el equipo)."""
    import threading
    import time
    yo = os.path.abspath(__file__)
    try:
        antes = os.path.getmtime(yo)
    except OSError:
        return

    def bucle():
        while True:
            time.sleep(10)
            try:
                if os.path.getmtime(yo) != antes:
                    time.sleep(3)                                 # que termine de copiarse
                    print("Portal actualizado: lo vuelvo a cargar", flush=True)
                    os.execv(sys.executable, [sys.executable, yo] + sys.argv[1:])
            except OSError:
                pass

    threading.Thread(target=bucle, daemon=True).start()


def main():
    os.makedirs(USUARIO, exist_ok=True)
    vigilar_actualizacion()
    srv = ThreadingHTTPServer(("0.0.0.0", PUERTO), Portal)
    print(f"Portal de ZF2 en http://0.0.0.0:{PUERTO}  (datos: {DATOS}, tus cambios: {USUARIO})", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
